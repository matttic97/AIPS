
public interface ComparableSequence<T extends Comparable> extends Sequence<T>{

}
