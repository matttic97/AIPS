public class CollectionException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CollectionException(String msg) {
		super(msg);
	}

}
