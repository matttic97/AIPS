public interface Collection {
	
	static final String ERR_MSG_EMPTY = "Collection is empty.";
	//static final String ERR_MSG_FULL = "Collection is full.";

    boolean isEmpty();
    //boolean isFull();
    int size();
    String toString();
    //void resize(Direction d);

}
