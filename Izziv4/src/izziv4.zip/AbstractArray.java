
public abstract interface AbstractArray<T extends Comparable<T>> extends PriorityQueue<T>{



}
